package Exercice3;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedType;
import java.lang.reflect.Executable;
import java.lang.reflect.TypeVariable;

import org.junit.jupiter.api.Test;
import  Exercice3.Grille;
import sun.reflect.generics.repository.ConstructorRepository;

;

abstract class GrilleTest {


	

			byte[] getAnnotationBytes() {
				// TODO Auto-generated method stub
				return null;
			}

			boolean hasGenericInformation() {
				// TODO Auto-generated method stub
				return false;
			}

			ConstructorRepository getGenericInfo() {
				// TODO Auto-generated method stub
				return null;
			}

			void specificToStringHeader(StringBuilder sb) {
				// TODO Auto-generated method stub
				
			}

			void specificToGenericStringHeader(StringBuilder sb) {
				// TODO Auto-generated method stub
				
			}

			public Class<?> getDeclaringClass() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getName() {
				// TODO Auto-generated method stub
				return null;
			}

			public int getModifiers() {
				// TODO Auto-generated method stub
				return 0;
			}

			public TypeVariable<?>[] getTypeParameters() {
				// TODO Auto-generated method stub
				return null;
			}

			Class<?>[] getSharedParameterTypes() {
				// TODO Auto-generated method stub
				return null;
			}

			Class<?>[] getSharedExceptionTypes() {
				// TODO Auto-generated method stub
				return null;
			}

			public Class<?>[] getParameterTypes() {
				// TODO Auto-generated method stub
				return null;
			}

			public Class<?>[] getExceptionTypes() {
				// TODO Auto-generated method stub
				return null;
			}

			public String toGenericString() {
				// TODO Auto-generated method stub
				return null;
			}

			public Annotation[][] getParameterAnnotations() {
				// TODO Auto-generated method stub
				return null;
			}

			boolean handleParameterNumberMismatch(int resultLength, int numParameters) {
				// TODO Auto-generated method stub
				return false;
			}

			public AnnotatedType getAnnotatedReturnType() {
				// TODO Auto-generated method stub
				return null;
			}
}
