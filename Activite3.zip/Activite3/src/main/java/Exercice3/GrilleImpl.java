package Exercice3;

public class GrilleImpl implements Grille {

	public int getDimension() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setValue(int x, int y, char value) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		
	}

	public char getValue(int x, int y) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean complete() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean possible(int x, int y, char value) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return false;
	}

		
		}


